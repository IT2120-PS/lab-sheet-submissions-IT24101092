setwd("C:/Users/HP/Desktop/IT24101092 PS Lab 3")
getwd()
student_data <- read.csv("Exercise.csv", header = TRUE)

# Summary statistics
summary(student_data$X1)

# Histogram
hist(student_data$X1,
     main="Histogram of Age",
     xlab="Age",
     col="lightblue",
     border="black")

# Frequency table
table(student_data$X2)

# Bar chart
barplot(table(student_data$X2),
        main="Gender Distribution",
        names.arg=c("Male","Female"),
        col=c("lightgreen","pink"))

# Boxplot
boxplot(X1 ~ X3, data=student_data,
        names=c("Home","Boarded","Lodging"),
        main="Age by Accommodation",
        xlab="Accommodation",
        ylab="Age",
        col=c("orange","lightblue","lightgreen"))

